-- Help Request Shift Report / getAreaSummary (master report only)
-- One row per area in {areas}, including areas with no requests this shift, busiest first
WITH shiftRequests AS (
    SELECT
        (SELECT MAX(Area) FROM WorkStationAssignment WHERE StationName = h.Station) AS Area,
        CASE WHEN closed.ClosedAt <= :endDate THEN 1 ELSE 0 END      AS ClosedInShift,
        CASE WHEN h.LineStopped = 1 THEN 1 ELSE 0 END                     AS LineStopped,
        DATEDIFF(SECOND, h.[Timestamp],
            CASE WHEN closed.ClosedAt <= :endDate THEN closed.ClosedAt ELSE :endDate END) AS SecondsOpen
    FROM HelpRequestedLog h
    -- When the request was closed, on the plant clock. CompletedTimestamp can't be used: it is written with the
    -- database server's clock (GETDATE(), UTC on this server) while [Timestamp] comes from the gateway in plant time,
    -- so add the UTC open time (TimestampUTC to CompletedTimestampUTC) to [Timestamp]
    CROSS APPLY (
        SELECT DATEADD(SECOND, DATEDIFF(SECOND, h.TimestampUTC, h.CompletedTimestampUTC), h.[Timestamp]) AS ClosedAt
    ) closed
    WHERE h.Station IN (SELECT StationName FROM WorkStationAssignment WHERE Area IN {areas})
      AND h.[Timestamp] >= :startDate
      AND h.[Timestamp] <  :endDate
)
SELECT
    a.Area,
    COUNT(r.Area)                                                         AS Requests,
    ISNULL(SUM(r.LineStopped), 0)                                         AS LineStopped,
    ISNULL(SUM(r.ClosedInShift), 0)                                       AS Closed,
    COUNT(r.Area) - ISNULL(SUM(r.ClosedInShift), 0)                       AS StillOpen,
    -- Average of the seconds open, rounded to whole minutes
    CAST(ROUND(ISNULL(AVG(CASE WHEN r.ClosedInShift = 1 THEN r.SecondsOpen * 1.0 END), 0) / 60.0, 0) AS int) AS AvgMinutesToClose
FROM (SELECT DISTINCT Area FROM WorkStationAssignment WHERE Area IN {areas}) a
LEFT JOIN shiftRequests r ON r.Area = a.Area
GROUP BY a.Area
ORDER BY Requests DESC, a.Area;

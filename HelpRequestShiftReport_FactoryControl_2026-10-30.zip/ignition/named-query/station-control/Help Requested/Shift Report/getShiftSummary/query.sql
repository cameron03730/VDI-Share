-- Help Request Shift Report / getShiftSummary
-- One row: the four shift numbers, plus CalledSummary ('Supervisors 3  ·  AMR 2') for the "Called" line.
-- A request counts as closed only if it was closed before the shift ended. Times are counted in seconds and
-- rounded to whole minutes at the end, so a request closed in 64 seconds counts as 1 minute, not 0 or 2
WITH shiftRequests AS (
    SELECT
        h.Contacts,
        CASE WHEN closed.ClosedAt <= :endDate THEN 1 ELSE 0 END      AS ClosedInShift,
        CASE WHEN h.LineStopped = 1 THEN 1 ELSE 0 END                     AS LineStopped,
        DATEDIFF(SECOND, h.[Timestamp],
            CASE WHEN closed.ClosedAt <= :endDate THEN closed.ClosedAt ELSE :endDate END) AS SecondsOpen
    FROM HelpRequestedLog h
    -- When the request was closed, on the plant clock. CompletedTimestamp can't be used: it is written with the
    -- database server's clock (GETDATE(), UTC on this server) while [Timestamp] comes from the gateway in plant time,
    -- so add the UTC open time (TimestampUTC to CompletedTimestampUTC) to [Timestamp]
    CROSS APPLY (
        SELECT DATEADD(SECOND, DATEDIFF(SECOND, h.TimestampUTC, h.CompletedTimestampUTC), h.[Timestamp]) AS ClosedAt
    ) closed
    WHERE h.Station IN (SELECT StationName FROM WorkStationAssignment WHERE Area IN {areas})
      AND h.[Timestamp] >= :startDate
      AND h.[Timestamp] <  :endDate
),
-- Contacts is the roster list the popup saved, e.g. 'Supervisors,Maintenance,'
called AS (
    SELECT LTRIM(RTRIM(c.value)) AS ResponderGroup, COUNT(*) AS Calls
    FROM shiftRequests r
    CROSS APPLY STRING_SPLIT(r.Contacts, ',') c
    WHERE LTRIM(RTRIM(c.value)) <> ''
    GROUP BY LTRIM(RTRIM(c.value))
)
SELECT
    totals.TotalRequests,
    totals.ClosedRequests,
    totals.TotalRequests - totals.ClosedRequests                          AS OpenRequests,
    totals.LineStoppedRequests,
    totals.LineStoppedMinutes,
    totals.AvgMinutesToClose,
    totals.LongestMinutes,
    ISNULL(calledList.CalledSummary, 'Nobody')                            AS CalledSummary
FROM (
    SELECT
        COUNT(*)                                                              AS TotalRequests,
        ISNULL(SUM(ClosedInShift), 0)                                         AS ClosedRequests,
        ISNULL(SUM(LineStopped), 0)                                           AS LineStoppedRequests,
        CAST(ROUND(ISNULL(SUM(LineStopped * SecondsOpen), 0) / 60.0, 0) AS int)                       AS LineStoppedMinutes,
        CAST(ROUND(ISNULL(AVG(CASE WHEN ClosedInShift = 1 THEN SecondsOpen * 1.0 END), 0) / 60.0, 0) AS int) AS AvgMinutesToClose,
        CAST(ROUND(ISNULL(MAX(SecondsOpen), 0) / 60.0, 0) AS int)                                     AS LongestMinutes
    FROM shiftRequests
) totals
CROSS JOIN (
    SELECT STRING_AGG(ResponderGroup + ' ' + CAST(Calls AS varchar(10)), N'  ·  ')
               WITHIN GROUP (ORDER BY Calls DESC, ResponderGroup)         AS CalledSummary
    FROM called
) calledList;

-- Help Request Shift Report / getRequestsByCategory
-- One heading row per Level 1 category (busiest first), then that category's requests in time order.
-- RowStyle picks the report row version: Heading, Open (still open at shift end, tinted) or Standard
WITH shiftRequests AS (
    SELECT
        h.[Timestamp]                                                   AS RequestTime,
        (SELECT MAX(Area) FROM WorkStationAssignment WHERE StationName = h.Station) AS Area,
        h.Station,
        ISNULL(NULLIF(h.CategoryL1, ''), 'Uncategorized')               AS CategoryL1,
        ISNULL(NULLIF(h.CategoryL2, ''), 'Not set')                     AS CategoryL2,
        CASE WHEN h.LineStopped = 1 THEN 1 ELSE 0 END                   AS LineStopped,
        CASE WHEN closed.ClosedAt <= :endDate THEN 1 ELSE 0 END    AS ClosedInShift,
        -- The popup saves Message as 'L1 : L2 - description', so cut the category prefix off
        CASE
            WHEN LEFT(h.Message, LEN(h.CategoryL1 + ' : ' + h.CategoryL2 + ' -') + 1) = h.CategoryL1 + ' : ' + h.CategoryL2 + ' - '
                THEN SUBSTRING(h.Message, LEN(h.CategoryL1 + ' : ' + h.CategoryL2 + ' -') + 2, 4000)
            ELSE h.Message
        END                                                             AS Description,
        h.ResolutionAction,
        -- Seconds open rounded to whole minutes, so 64 seconds is 1 minute
        CAST(ROUND(DATEDIFF(SECOND, h.[Timestamp],
            CASE WHEN closed.ClosedAt <= :endDate THEN closed.ClosedAt ELSE :endDate END) / 60.0, 0) AS int) AS MinutesOpen
    FROM HelpRequestedLog h
    -- When the request was closed, on the plant clock. CompletedTimestamp can't be used: it is written with the
    -- database server's clock (GETDATE(), UTC on this server) while [Timestamp] comes from the gateway in plant time,
    -- so add the UTC open time (TimestampUTC to CompletedTimestampUTC) to [Timestamp]
    CROSS APPLY (
        SELECT DATEADD(SECOND, DATEDIFF(SECOND, h.TimestampUTC, h.CompletedTimestampUTC), h.[Timestamp]) AS ClosedAt
    ) closed
    WHERE h.Station IN (SELECT StationName FROM WorkStationAssignment WHERE Area IN {areas})
      AND h.[Timestamp] >= :startDate
      AND h.[Timestamp] <  :endDate
),
categories AS (
    SELECT CategoryL1, COUNT(*) AS Requests, SUM(LineStopped) AS LineStopped, SUM(MinutesOpen) AS MinutesOpen
    FROM shiftRequests
    GROUP BY CategoryL1
)
SELECT RowStyle, Heading, HeadingDetail, RequestTime, Area, Station, Problem, LineStoppedMark, Description, Resolution, MinutesOpen
FROM (
    -- Category heading rows
    SELECT
        'Heading'                                                       AS RowStyle,
        c.CategoryL1                                                    AS Heading,
        CAST(c.Requests AS varchar(10)) + CASE WHEN c.Requests = 1 THEN ' request' ELSE ' requests' END
            + CASE WHEN c.LineStopped > 0 THEN ', ' + CAST(c.LineStopped AS varchar(10)) + ' stopped the line' ELSE '' END
                                                                        AS HeadingDetail,
        NULL                                                            AS RequestTime,
        ''                                                              AS Area,
        ''                                                              AS Station,
        ''                                                              AS Problem,
        N''                                                             AS LineStoppedMark,
        ''                                                              AS Description,
        ''                                                              AS Resolution,
        c.MinutesOpen,
        c.Requests                                                      AS GroupRequests,
        c.CategoryL1                                                    AS GroupName,
        1                                                               AS RowOrder
    FROM categories c
    UNION ALL
    -- The requests under each heading
    SELECT
        CASE WHEN r.ClosedInShift = 1 THEN 'Standard' ELSE 'Open' END,
        '',
        '',
        r.RequestTime,
        r.Area,
        r.Station,
        r.CategoryL2,
        CASE WHEN r.LineStopped = 1 THEN N'★ ' ELSE N'' END,
        r.Description,
        CASE WHEN r.ClosedInShift = 1 THEN r.ResolutionAction ELSE 'Open at shift end' END,
        r.MinutesOpen,
        c.Requests,
        r.CategoryL1,
        2
    FROM shiftRequests r
    INNER JOIN categories c ON c.CategoryL1 = r.CategoryL1
    UNION ALL
    -- One line when the shift had no requests, so the table isn't an empty header
    SELECT 'Heading', 'No help requests this shift', '', NULL, '', '', '', N'', '', '', NULL, 0, '', 1
    WHERE NOT EXISTS (SELECT 1 FROM shiftRequests)
) grouped
ORDER BY GroupRequests DESC, GroupName, RowOrder, RequestTime;

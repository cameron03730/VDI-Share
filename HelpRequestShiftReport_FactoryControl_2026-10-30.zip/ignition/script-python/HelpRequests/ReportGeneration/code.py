"""
Purpose: Runs the Help Request reports on the front end for the back-end timer
Author: Cameron Metzgar
Company: MDI
Initial Date: 10/29/2026
Update Date:
Comment: Report resources live in FactoryControl, so Back-End-1 (HelpRequests.ShiftReport) calls
	executeReport through the executeFunction message handler and gets the PDF back.
"""


def executeReport(reportPath, params):
	'''
	Runs a FactoryControl report and returns it as PDF bytes.

	Args:
		reportPath (str): Report path in FactoryControl, e.g. 'Help Requests/Help Request Shift Report'.
		params (dict): Report parameters: startDate, endDate, shiftName, areaName, areas.

	Returns:
		bytes: The report as a PDF.
	'''
	return system.report.executeReport(
		path = reportPath,
		project = 'FactoryControl',
		parameters = params,
		fileType = 'PDF'
	)

-- Help Request Shift Report / getCategoryBreakdown
-- Level 1 total rows (RowLevel 1), each followed by its Level 2 rows (RowLevel 2), busiest Level 1 first
WITH shiftRequests AS (
    SELECT
        ISNULL(NULLIF(h.CategoryL1, ''), 'Uncategorized')   AS CategoryL1,
        ISNULL(NULLIF(h.CategoryL2, ''), 'Not set')         AS CategoryL2,
        CASE WHEN h.LineStopped = 1 THEN 1 ELSE 0 END       AS LineStopped,
        DATEDIFF(MINUTE, h.[Timestamp],
            CASE WHEN h.CompletedTimestamp <= :endDate THEN h.CompletedTimestamp ELSE :endDate END) AS MinutesOpen
    FROM HelpRequestedLog h
    WHERE h.Station IN (SELECT StationName FROM WorkStationAssignment WHERE Area IN {areas})
      AND h.[Timestamp] >= :startDate
      AND h.[Timestamp] <  :endDate
),
level1 AS (
    SELECT CategoryL1, COUNT(*) AS Requests, SUM(LineStopped) AS LineStopped, SUM(MinutesOpen) AS MinutesOpen
    FROM shiftRequests
    GROUP BY CategoryL1
)
SELECT RowLevel, Level1, Level2, Requests, LineStopped, MinutesOpen
FROM (
    SELECT 1 AS RowLevel, l.CategoryL1 AS Level1, '' AS Level2, l.Requests, l.LineStopped, l.MinutesOpen,
           l.Requests AS GroupRequests, l.CategoryL1 AS GroupName
    FROM level1 l
    UNION ALL
    SELECT 2, '', s.CategoryL2, COUNT(*), SUM(s.LineStopped), SUM(s.MinutesOpen),
           MAX(l.Requests), s.CategoryL1
    FROM shiftRequests s
    INNER JOIN level1 l ON l.CategoryL1 = s.CategoryL1
    GROUP BY s.CategoryL1, s.CategoryL2
) breakdown
ORDER BY GroupRequests DESC, GroupName, RowLevel, Requests DESC, Level2;

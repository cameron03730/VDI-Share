-- Help Request Shift Report / getShiftRequests
-- Every request raised this shift. The popup saves Message as 'L1 : L2 - description', so the category prefix is cut off here
SELECT
    h.[Timestamp]                                                       AS RequestTime,
    (SELECT MAX(Area) FROM WorkStationAssignment WHERE StationName = h.Station) AS Area,
    h.Station,
    ISNULL(NULLIF(h.CategoryL1, ''), 'Uncategorized') + N' › '
        + ISNULL(NULLIF(h.CategoryL2, ''), 'Not set')                   AS Category,
    CASE WHEN h.LineStopped = 1 THEN N'★ ' ELSE N'' END                 AS LineStoppedMark,
    CASE
        WHEN LEFT(h.Message, LEN(h.CategoryL1 + ' : ' + h.CategoryL2 + ' -') + 1) = h.CategoryL1 + ' : ' + h.CategoryL2 + ' - '
            THEN SUBSTRING(h.Message, LEN(h.CategoryL1 + ' : ' + h.CategoryL2 + ' -') + 2, 4000)
        ELSE h.Message
    END                                                                 AS Description,
    CASE WHEN h.CompletedTimestamp <= :endDate THEN h.ResolutionAction
         ELSE 'Open at shift end' END                                   AS Resolution,
    DATEDIFF(MINUTE, h.[Timestamp],
        CASE WHEN h.CompletedTimestamp <= :endDate THEN h.CompletedTimestamp ELSE :endDate END) AS MinutesOpen
FROM HelpRequestedLog h
WHERE h.Station IN (SELECT StationName FROM WorkStationAssignment WHERE Area IN {areas})
  AND h.[Timestamp] >= :startDate
  AND h.[Timestamp] <  :endDate
ORDER BY h.[Timestamp];

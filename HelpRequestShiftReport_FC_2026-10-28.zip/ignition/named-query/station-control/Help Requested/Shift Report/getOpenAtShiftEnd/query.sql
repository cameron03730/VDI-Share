-- Help Request Shift Report / getOpenAtShiftEnd
-- Requests raised this shift that were still open when it ended, so the next shift picks them up
SELECT
    h.[Timestamp]                                                       AS RequestTime,
    (SELECT MAX(Area) FROM WorkStationAssignment WHERE StationName = h.Station) AS Area,
    h.Station,
    ISNULL(NULLIF(h.CategoryL1, ''), 'Uncategorized') + N' › '
        + ISNULL(NULLIF(h.CategoryL2, ''), 'Not set')                   AS Category,
    CASE WHEN h.LineStopped = 1 THEN N'★ ' ELSE N'' END                 AS LineStoppedMark,
    CASE
        WHEN LEFT(h.Message, LEN(h.CategoryL1 + ' : ' + h.CategoryL2 + ' -') + 1) = h.CategoryL1 + ' : ' + h.CategoryL2 + ' - '
            THEN SUBSTRING(h.Message, LEN(h.CategoryL1 + ' : ' + h.CategoryL2 + ' -') + 2, 4000)
        ELSE h.Message
    END                                                                 AS Description,
    REPLACE(CASE WHEN RIGHT(h.Contacts, 1) = ',' THEN LEFT(h.Contacts, LEN(h.Contacts) - 1)
                 ELSE h.Contacts END, ',', ', ')                        AS Called,
    DATEDIFF(MINUTE, h.[Timestamp], :endDate)                           AS MinutesOpen
FROM HelpRequestedLog h
WHERE h.Station IN (SELECT StationName FROM WorkStationAssignment WHERE Area IN {areas})
  AND h.[Timestamp] >= :startDate
  AND h.[Timestamp] <  :endDate
  AND (h.CompletedTimestamp IS NULL OR h.CompletedTimestamp > :endDate)
ORDER BY h.[Timestamp];

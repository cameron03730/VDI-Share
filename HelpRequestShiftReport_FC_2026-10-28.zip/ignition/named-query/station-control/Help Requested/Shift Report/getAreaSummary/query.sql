-- Help Request Shift Report / getAreaSummary (master report only)
-- One row per area in {areas}, including areas with no requests this shift, busiest first
WITH shiftRequests AS (
    SELECT
        (SELECT MAX(Area) FROM WorkStationAssignment WHERE StationName = h.Station) AS Area,
        CASE WHEN h.CompletedTimestamp <= :endDate THEN 1 ELSE 0 END      AS ClosedInShift,
        CASE WHEN h.LineStopped = 1 THEN 1 ELSE 0 END                     AS LineStopped,
        DATEDIFF(MINUTE, h.[Timestamp],
            CASE WHEN h.CompletedTimestamp <= :endDate THEN h.CompletedTimestamp ELSE :endDate END) AS MinutesOpen
    FROM HelpRequestedLog h
    WHERE h.Station IN (SELECT StationName FROM WorkStationAssignment WHERE Area IN {areas})
      AND h.[Timestamp] >= :startDate
      AND h.[Timestamp] <  :endDate
)
SELECT
    a.Area,
    COUNT(r.Area)                                                         AS Requests,
    ISNULL(SUM(r.LineStopped), 0)                                         AS LineStopped,
    ISNULL(SUM(r.ClosedInShift), 0)                                       AS Closed,
    COUNT(r.Area) - ISNULL(SUM(r.ClosedInShift), 0)                       AS StillOpen,
    ISNULL(AVG(CASE WHEN r.ClosedInShift = 1 THEN r.MinutesOpen END), 0)  AS AvgMinutesToClose
FROM (SELECT DISTINCT Area FROM WorkStationAssignment WHERE Area IN {areas}) a
LEFT JOIN shiftRequests r ON r.Area = a.Area
GROUP BY a.Area
ORDER BY Requests DESC, a.Area;

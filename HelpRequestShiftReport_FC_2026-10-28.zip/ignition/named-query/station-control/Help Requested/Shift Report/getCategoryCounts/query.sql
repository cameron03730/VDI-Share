-- Help Request Shift Report / getCategoryCounts
-- Bar chart data: requests and line-stopped requests per Level 1 category, busiest first
SELECT
    ISNULL(NULLIF(h.CategoryL1, ''), 'Uncategorized')       AS Category,
    COUNT(*)                                                AS Requests,
    SUM(CASE WHEN h.LineStopped = 1 THEN 1 ELSE 0 END)      AS [Line Stopped]
FROM HelpRequestedLog h
WHERE h.Station IN (SELECT StationName FROM WorkStationAssignment WHERE Area IN {areas})
  AND h.[Timestamp] >= :startDate
  AND h.[Timestamp] <  :endDate
GROUP BY ISNULL(NULLIF(h.CategoryL1, ''), 'Uncategorized')
ORDER BY Requests DESC, Category;

-- Help Request Shift Report / getShiftSummary
-- One row of shift totals for the summary tiles. A request counts as closed only if it was closed before the shift ended
SELECT
    COUNT(*)                                                              AS TotalRequests,
    ISNULL(SUM(r.ClosedInShift), 0)                                       AS ClosedRequests,
    COUNT(*) - ISNULL(SUM(r.ClosedInShift), 0)                            AS OpenRequests,
    ISNULL(SUM(r.LineStopped), 0)                                         AS LineStoppedRequests,
    ISNULL(SUM(r.LineStopped * r.MinutesOpen), 0)                         AS LineStoppedMinutes,
    ISNULL(AVG(CASE WHEN r.ClosedInShift = 1 THEN r.MinutesOpen END), 0)  AS AvgMinutesToClose,
    ISNULL(MAX(r.MinutesOpen), 0)                                         AS LongestMinutes
FROM HelpRequestedLog h
CROSS APPLY (
    SELECT
        CASE WHEN h.CompletedTimestamp <= :endDate THEN 1 ELSE 0 END      AS ClosedInShift,
        CASE WHEN h.LineStopped = 1 THEN 1 ELSE 0 END                     AS LineStopped,
        DATEDIFF(MINUTE, h.[Timestamp],
            CASE WHEN h.CompletedTimestamp <= :endDate THEN h.CompletedTimestamp ELSE :endDate END) AS MinutesOpen
) r
WHERE h.Station IN (SELECT StationName FROM WorkStationAssignment WHERE Area IN {areas})
  AND h.[Timestamp] >= :startDate
  AND h.[Timestamp] <  :endDate;

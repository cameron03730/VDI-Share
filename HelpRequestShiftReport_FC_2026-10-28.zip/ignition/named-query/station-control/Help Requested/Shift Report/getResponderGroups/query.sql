-- Help Request Shift Report / getResponderGroups
-- How many requests went to each responder group. Contacts is the roster list the popup saved, e.g. 'Supervisors,Maintenance,'
SELECT
    LTRIM(RTRIM(c.value))   AS ResponderGroup,
    COUNT(*)                AS Calls
FROM HelpRequestedLog h
CROSS APPLY STRING_SPLIT(h.Contacts, ',') c
WHERE h.Station IN (SELECT StationName FROM WorkStationAssignment WHERE Area IN {areas})
  AND h.[Timestamp] >= :startDate
  AND h.[Timestamp] <  :endDate
  AND LTRIM(RTRIM(c.value)) <> ''
GROUP BY LTRIM(RTRIM(c.value))
ORDER BY Calls DESC, ResponderGroup;

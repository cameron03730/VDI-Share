-- Help Request Shift Report / getTopStations
-- The five stations with the most requests this shift, then the most minutes open
SELECT TOP 5
    h.Station,
    (SELECT MAX(Area) FROM WorkStationAssignment WHERE StationName = h.Station) AS Area,
    COUNT(*)                                                                AS Calls,
    SUM(DATEDIFF(MINUTE, h.[Timestamp],
        CASE WHEN h.CompletedTimestamp <= :endDate THEN h.CompletedTimestamp ELSE :endDate END)) AS MinutesOpen
FROM HelpRequestedLog h
WHERE h.Station IN (SELECT StationName FROM WorkStationAssignment WHERE Area IN {areas})
  AND h.[Timestamp] >= :startDate
  AND h.[Timestamp] <  :endDate
GROUP BY h.Station
ORDER BY Calls DESC, MinutesOpen DESC, h.Station;

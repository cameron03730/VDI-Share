import { useMemo, useState } from "react";
import {
  X,
  Wrench,
  HardHat,
  ClipboardCheck,
  Bolt,
  SprayCan,
  Users,
  AlertOctagon,
  CheckCircle2,
  Loader2,
  AlertTriangle,
  Flame,
  Zap,
  Cog,
  PackageX,
  ShieldAlert,
  FileWarning,
  Timer,
  Ban,
  type LucideIcon,
} from "lucide-react";

export type PlcState = {
  PB_Enable: boolean;
  PB_Toggle: boolean;
};

export type HelpRequestPayload = {
  roles: string[];
  message: string;
  priority: "low" | "medium" | "high" | "critical";
  category: string;
  lineStopped: boolean;
  safetyIssue: boolean;
  partNumber: string;
  estimatedDowntimeMin: number | null;
};

type Role = {
  id: string;
  name: string;
  description: string;
  Icon: LucideIcon;
};

const ROLES: Role[] = [
  { id: "maintenance", name: "Maintenance", description: "Mechanical & repair", Icon: Wrench },
  { id: "team-lead", name: "Team Lead", description: "Line coordinator", Icon: HardHat },
  { id: "supervisor", name: "Supervisor", description: "Area supervisor", Icon: Users },
  { id: "quality", name: "Quality", description: "QA / inspection", Icon: ClipboardCheck },
  { id: "materials", name: "Materials", description: "Parts & handling", Icon: Bolt },
  { id: "engineering", name: "Engineering", description: "Process engineer", Icon: SprayCan },
];

type Category = { id: string; name: string; Icon: LucideIcon };
const CATEGORIES: Category[] = [
  { id: "mechanical", name: "Mechanical", Icon: Cog },
  { id: "electrical", name: "Electrical", Icon: Zap },
  { id: "quality", name: "Quality", Icon: ClipboardCheck },
  { id: "materials", name: "Materials", Icon: PackageX },
  { id: "safety", name: "Safety", Icon: ShieldAlert },
  { id: "process", name: "Process", Icon: FileWarning },
];

type Priority = HelpRequestPayload["priority"];
const PRIORITIES: {
  id: Priority;
  label: string;
  sub: string;
  cls: string;
  Icon: LucideIcon;
}[] = [
  {
    id: "low",
    label: "Low",
    sub: "Non-urgent",
    cls: "border-fg-muted text-fg-secondary data-[on=true]:bg-surface-3 data-[on=true]:border-fg-secondary",
    Icon: Timer,
  },
  {
    id: "medium",
    label: "Medium",
    sub: "Slowing down",
    cls: "border-accent text-accent data-[on=true]:bg-accent-subtle",
    Icon: AlertTriangle,
  },
  {
    id: "high",
    label: "High",
    sub: "Line at risk",
    cls: "border-warning text-warning data-[on=true]:bg-warning-subtle",
    Icon: AlertOctagon,
  },
  {
    id: "critical",
    label: "Critical",
    sub: "Safety / stopped",
    cls: "border-danger text-danger data-[on=true]:bg-danger/25",
    Icon: Flame,
  },
];

const DOWNTIME_OPTIONS = [5, 15, 30, 60];

type Props = {
  stationName: string;
  location: string;
  plc: PlcState;
  onSubmit: (payload: HelpRequestPayload) => void;
  onCancelRequest: () => void;
  onClose: () => void;
};

type Phase = "idle" | "submitting" | "confirmed";

export function HelpRequestPopup({
  stationName,
  location,
  plc,
  onSubmit,
  onCancelRequest,
  onClose,
}: Props) {
  const [selected, setSelected] = useState<string[]>([]);
  const [message, setMessage] = useState("");
  const [priority, setPriority] = useState<Priority>("medium");
  const [category, setCategory] = useState<string>("");
  const [lineStopped, setLineStopped] = useState(false);
  const [safetyIssue, setSafetyIssue] = useState(false);
  const [partNumber, setPartNumber] = useState("");
  const [downtime, setDowntime] = useState<number | null>(null);
  const [phase, setPhase] = useState<Phase>("idle");

  const isActive = plc.PB_Toggle;
  const isEnabled = plc.PB_Enable;
  const canSubmit =
    selected.length > 0 &&
    category !== "" &&
    !isActive &&
    isEnabled &&
    phase === "idle";

  const toggleRole = (id: string) => {
    if (isActive || !isEnabled) return;
    setSelected((s) => (s.includes(id) ? s.filter((r) => r !== id) : [...s, id]));
  };

  const submit = () => {
    if (!canSubmit) return;
    setPhase("submitting");
    setTimeout(() => {
      onSubmit({
        roles: selected,
        message: message.trim().slice(0, 1000),
        priority,
        category,
        lineStopped,
        safetyIssue,
        partNumber: partNumber.trim().slice(0, 40),
        estimatedDowntimeMin: downtime,
      });
      setPhase("confirmed");
      setTimeout(() => onClose(), 1500);
    }, 700);
  };

  const primary = useMemo(() => {
    if (!isEnabled)
      return { label: "Unavailable", cls: "bg-surface-3 text-fg-muted", disabled: true };
    if (isActive)
      return {
        label: "Cancel Help Request",
        cls: "bg-warning text-warning-fg hover:brightness-95",
        disabled: false,
      };
    if (phase === "submitting")
      return {
        label: "Sending…",
        cls: "bg-accent/70 text-accent-fg",
        disabled: true,
        loading: true,
      };
    if (phase === "confirmed")
      return { label: "Sent", cls: "bg-success text-success-fg", disabled: true };
    if (canSubmit)
      return {
        label: "Request Help",
        cls: "bg-accent text-accent-fg hover:brightness-105 shadow-lg shadow-accent/20",
        disabled: false,
      };
    if (selected.length === 0)
      return { label: "Select a contact", cls: "bg-surface-3 text-fg-muted", disabled: true };
    return { label: "Select a category", cls: "bg-surface-3 text-fg-muted", disabled: true };
  }, [isEnabled, isActive, phase, canSubmit, selected.length]);

  const selectedNames = selected
    .map((id) => ROLES.find((r) => r.id === id)?.name)
    .filter(Boolean)
    .join(", ");

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <div
        role="dialog"
        aria-labelledby="help-title"
        className="w-full max-w-[720px] rounded-2xl bg-surface-1 border border-border shadow-2xl flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between p-6 pb-4">
          <div className="flex flex-col gap-1">
            <h2 id="help-title" className="text-3xl font-bold tracking-tight">
              Request Help
            </h2>
            <p className="text-base text-fg-secondary font-medium">
              {stationName} <span className="text-fg-muted">·</span> {location}
            </p>
          </div>
          <button
            aria-label="Close"
            onClick={onClose}
            className="h-11 w-11 flex items-center justify-center rounded-lg hover:bg-surface-2 text-fg-secondary transition"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="px-6 pb-6 flex flex-col gap-6 overflow-y-auto">
          {isActive && phase !== "confirmed" && (
            <div className="flex items-start gap-3 rounded-xl bg-warning-subtle border-l-4 border-warning p-4">
              <AlertOctagon className="h-7 w-7 text-warning shrink-0 mt-0.5" />
              <div className="flex flex-col">
                <span className="font-semibold text-fg-primary text-lg">
                  Help already requested for this station
                </span>
                <span className="text-sm text-fg-secondary">
                  Notified roles will respond shortly. You can cancel below.
                </span>
              </div>
            </div>
          )}

          {phase === "confirmed" && (
            <div className="flex items-start gap-3 rounded-xl bg-success-subtle border-l-4 border-success p-4">
              <CheckCircle2 className="h-7 w-7 text-success shrink-0 mt-0.5" />
              <div className="flex flex-col">
                <span className="font-semibold text-fg-primary text-lg">
                  Help requested · {priority.toUpperCase()}
                </span>
                <span className="text-sm text-fg-secondary">
                  {selectedNames} notified
                </span>
              </div>
            </div>
          )}

          {!isActive && phase !== "confirmed" && (
            <>
              {/* Priority */}
              <section className="flex flex-col gap-3">
                <div className="flex items-baseline justify-between">
                  <h3 className="text-xl font-semibold">Priority</h3>
                  <span className="text-sm text-fg-muted">
                    How urgent is this?
                  </span>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {PRIORITIES.map(({ id, label, sub, cls, Icon }) => {
                    const on = priority === id;
                    return (
                      <button
                        key={id}
                        type="button"
                        data-on={on}
                        onClick={() => setPriority(id)}
                        className={`min-h-[72px] rounded-xl border-2 bg-surface-2 px-3 py-2 flex flex-col items-start gap-1 transition active:scale-[0.98] ${cls}`}
                      >
                        <div className="flex items-center gap-2">
                          <Icon className="h-5 w-5" />
                          <span className="text-base font-bold">{label}</span>
                        </div>
                        <span className="text-xs text-fg-muted">{sub}</span>
                      </button>
                    );
                  })}
                </div>
              </section>

              {/* Category */}
              <section className="flex flex-col gap-3">
                <div className="flex items-baseline justify-between">
                  <h3 className="text-xl font-semibold">Issue category</h3>
                  <span className="text-sm text-fg-muted">Required</span>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {CATEGORIES.map(({ id, name, Icon }) => {
                    const on = category === id;
                    return (
                      <button
                        key={id}
                        type="button"
                        onClick={() => setCategory(on ? "" : id)}
                        aria-pressed={on}
                        className={`min-h-[80px] rounded-xl border-2 bg-surface-2 px-3 py-2 flex flex-col items-center justify-center gap-1 transition active:scale-[0.98] ${
                          on
                            ? "border-accent bg-accent-subtle text-accent"
                            : "border-transparent text-fg-secondary"
                        }`}
                      >
                        <Icon className="h-6 w-6" />
                        <span className="text-sm font-semibold text-fg-primary">
                          {name}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </section>

              {/* Roles */}
              <section className="flex flex-col gap-3">
                <div className="flex items-baseline justify-between">
                  <h3 className="text-xl font-semibold">Who should respond?</h3>
                  <span className="text-sm text-fg-muted">
                    Select one or more
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  {ROLES.map(({ id, name, description, Icon }) => {
                    const isSel = selected.includes(id);
                    return (
                      <button
                        key={id}
                        type="button"
                        onClick={() => toggleRole(id)}
                        aria-pressed={isSel}
                        className={`tile-role text-left p-4 min-h-[92px] flex flex-col gap-2 active:scale-[0.98] ${
                          isSel ? "tile-role-selected" : ""
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <Icon
                            className={`h-7 w-7 ${
                              isSel ? "text-accent" : "text-fg-secondary"
                            }`}
                          />
                          <span
                            className={`h-6 w-6 rounded-md border-2 flex items-center justify-center ${
                              isSel
                                ? "bg-accent border-accent"
                                : "border-border"
                            }`}
                          >
                            {isSel && (
                              <CheckCircle2 className="h-5 w-5 text-accent-fg" />
                            )}
                          </span>
                        </div>
                        <div className="flex flex-col">
                          <span className="text-base font-semibold text-fg-primary">
                            {name}
                          </span>
                          <span className="text-xs text-fg-muted">
                            {description}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </section>

              {/* Impact toggles */}
              <section className="flex flex-col gap-3">
                <h3 className="text-xl font-semibold">Impact</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <ToggleTile
                    on={lineStopped}
                    onChange={() => setLineStopped((v) => !v)}
                    Icon={Ban}
                    label="Line stopped"
                    sub="Production halted"
                    tone="warning"
                  />
                  <ToggleTile
                    on={safetyIssue}
                    onChange={() => setSafetyIssue((v) => !v)}
                    Icon={ShieldAlert}
                    label="Safety concern"
                    sub="Person or asset at risk"
                    tone="danger"
                  />
                </div>
              </section>

              {/* Estimated downtime */}
              <section className="flex flex-col gap-3">
                <div className="flex items-baseline justify-between">
                  <h3 className="text-xl font-semibold">
                    Est. downtime{" "}
                    <span className="text-sm text-fg-muted font-normal">
                      (optional)
                    </span>
                  </h3>
                </div>
                <div className="grid grid-cols-5 gap-2">
                  {DOWNTIME_OPTIONS.map((min) => {
                    const on = downtime === min;
                    return (
                      <button
                        key={min}
                        type="button"
                        onClick={() => setDowntime(on ? null : min)}
                        className={`min-h-[52px] rounded-lg border-2 font-semibold text-base transition active:scale-[0.98] ${
                          on
                            ? "border-accent bg-accent-subtle text-accent"
                            : "border-transparent bg-surface-2 text-fg-secondary"
                        }`}
                      >
                        {min < 60 ? `${min} min` : `1 hr`}
                      </button>
                    );
                  })}
                  <button
                    type="button"
                    onClick={() => setDowntime(downtime === -1 ? null : -1)}
                    className={`min-h-[52px] rounded-lg border-2 font-semibold text-base transition active:scale-[0.98] ${
                      downtime === -1
                        ? "border-danger bg-danger/20 text-danger"
                        : "border-transparent bg-surface-2 text-fg-secondary"
                    }`}
                  >
                    Unknown
                  </button>
                </div>
              </section>

              {/* Part number + message */}
              <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex flex-col gap-2 md:col-span-1">
                  <label className="text-base font-semibold">
                    Part / job #{" "}
                    <span className="text-sm text-fg-muted font-normal">
                      (optional)
                    </span>
                  </label>
                  <input
                    value={partNumber}
                    onChange={(e) => setPartNumber(e.target.value)}
                    placeholder="e.g. 91234-07"
                    maxLength={40}
                    className="h-12 rounded-xl bg-surface-2 border border-border px-4 text-base text-fg-primary placeholder:text-fg-muted focus:outline-none focus:border-accent"
                  />
                </div>
                <div className="flex flex-col gap-2 md:col-span-2">
                  <label className="text-base font-semibold">
                    Message{" "}
                    <span className="text-sm text-fg-muted font-normal">
                      (optional)
                    </span>
                  </label>
                  <textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value.slice(0, 1000))}
                    placeholder="Describe the issue (optional)"
                    rows={2}
                    className="rounded-xl bg-surface-2 border border-border px-4 py-3 text-base text-fg-primary placeholder:text-fg-muted focus:outline-none focus:border-accent resize-none min-h-[72px]"
                  />
                  <span className="text-xs text-fg-muted self-end">
                    {message.length}/1000
                  </span>
                </div>
              </section>
            </>
          )}
        </div>

        {/* Action bar */}
        <div className="flex gap-3 p-6 pt-4 border-t border-border mt-auto">
          <button
            onClick={onClose}
            className="h-14 px-6 rounded-xl bg-surface-2 hover:bg-surface-3 text-fg-primary font-semibold text-base flex-1 transition"
          >
            Cancel
          </button>
          <button
            onClick={isActive ? onCancelRequest : submit}
            disabled={primary.disabled}
            className={`h-14 px-6 rounded-xl font-bold text-lg flex-[2] flex items-center justify-center gap-2 transition ${primary.cls} disabled:cursor-not-allowed`}
          >
            {primary.loading && <Loader2 className="h-5 w-5 animate-spin" />}
            {primary.label}
          </button>
        </div>
      </div>
    </div>
  );
}

function ToggleTile({
  on,
  onChange,
  Icon,
  label,
  sub,
  tone,
}: {
  on: boolean;
  onChange: () => void;
  Icon: LucideIcon;
  label: string;
  sub: string;
  tone: "warning" | "danger";
}) {
  const onCls =
    tone === "danger"
      ? "border-danger bg-danger/20 text-danger"
      : "border-warning bg-warning-subtle text-warning";
  return (
    <button
      type="button"
      onClick={onChange}
      aria-pressed={on}
      className={`min-h-[72px] rounded-xl border-2 px-4 py-3 flex items-center gap-3 transition active:scale-[0.98] ${
        on ? onCls : "border-transparent bg-surface-2 text-fg-secondary"
      }`}
    >
      <Icon className="h-7 w-7 shrink-0" />
      <div className="flex flex-col items-start">
        <span className="text-base font-semibold text-fg-primary">{label}</span>
        <span className="text-xs text-fg-muted">{sub}</span>
      </div>
      <span
        className={`ml-auto h-7 w-12 rounded-full transition relative ${
          on ? "bg-current" : "bg-surface-3"
        }`}
      >
        <span
          className={`absolute top-0.5 h-6 w-6 rounded-full bg-white transition ${
            on ? "left-[22px]" : "left-0.5"
          }`}
        />
      </span>
    </button>
  );
}

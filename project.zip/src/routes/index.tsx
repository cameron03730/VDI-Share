import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { LifeBuoy, Power, CircleDot } from "lucide-react";
import {
  HelpRequestPopup,
  type PlcState,
  type HelpRequestPayload,
} from "@/components/HelpRequestPopup";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Station Control · Help Request" },
      {
        name: "description",
        content:
          "Industrial HMI station control screen with redesigned Help Request popup for factory operators.",
      },
      { property: "og:title", content: "Station Control · Help Request" },
      {
        property: "og:description",
        content:
          "Touch-first help request workflow for Perspective manufacturing HMI.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

type LogEntry = {
  id: number;
  station: string;
  contacts: string;
  message: string;
  priority: HelpRequestPayload["priority"];
  category: string;
  lineStopped: boolean;
  safetyIssue: boolean;
  partNumber: string;
  estimatedDowntimeMin: number | null;
  status: "Open" | "Closed";
  timestamp: string;
};

const PRIORITY_STYLES: Record<HelpRequestPayload["priority"], string> = {
  low: "bg-surface-3 text-fg-secondary",
  medium: "bg-accent-subtle text-accent",
  high: "bg-warning-subtle text-warning",
  critical: "bg-danger/25 text-danger",
};

function Index() {
  const [open, setOpen] = useState(false);
  const [plc, setPlc] = useState<PlcState>({ PB_Enable: true, PB_Toggle: false });
  const [log, setLog] = useState<LogEntry[]>([]);
  const [nextId, setNextId] = useState(1);

  const station = "BF-014";
  const location = "Boom Fab";

  const openEntry = log.find((l) => l.status === "Open");

  const handleSubmit = (payload: HelpRequestPayload) => {
    setLog((l) => [
      {
        id: nextId,
        station,
        contacts: payload.roles.join(","),
        message: payload.message,
        priority: payload.priority,
        category: payload.category,
        lineStopped: payload.lineStopped,
        safetyIssue: payload.safetyIssue,
        partNumber: payload.partNumber,
        estimatedDowntimeMin: payload.estimatedDowntimeMin,
        status: "Open",
        timestamp: new Date().toISOString(),
      },
      ...l,
    ]);
    setNextId((n) => n + 1);
    setPlc((p) => ({ ...p, PB_Toggle: true }));
  };

  const handleCancelRequest = () => {
    setPlc((p) => ({ ...p, PB_Toggle: false }));
    if (openEntry) {
      setLog((l) =>
        l.map((e) => (e.id === openEntry.id ? { ...e, status: "Closed" as const } : e)),
      );
    }
    setOpen(false);
  };

  const helpBtnStyle = !plc.PB_Enable
    ? "bg-surface-3 text-fg-muted cursor-not-allowed"
    : plc.PB_Toggle
      ? "bg-warning text-warning-fg animate-pulse shadow-lg shadow-warning/40"
      : "bg-accent text-accent-fg hover:brightness-105 shadow-lg shadow-accent/30";

  return (
    <main className="min-h-screen p-6 md:p-10">
      <div className="max-w-6xl mx-auto flex flex-col gap-8">
        <header className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-sm uppercase tracking-widest text-fg-muted">
              JLG Jefferson City · Station Control
            </p>
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight mt-1">
              {station}
              <span className="text-fg-muted"> · </span>
              <span className="text-fg-secondary">{location}</span>
            </h1>
          </div>
          <div className="flex items-center gap-2 rounded-xl bg-surface-1 border border-border px-4 py-2">
            <CircleDot
              className={`h-4 w-4 ${plc.PB_Toggle ? "text-warning animate-pulse" : "text-success"}`}
            />
            <span className="text-sm font-medium">
              Status: {plc.PB_Toggle ? "Help Requested (Bit 7)" : "Running"}
            </span>
          </div>
        </header>

        <section className="rounded-2xl bg-surface-1 border border-border p-6">
          <p className="text-xs uppercase tracking-widest text-fg-muted mb-4">
            Station Buttons
          </p>
          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => setOpen(true)}
              disabled={!plc.PB_Enable}
              className={`h-16 px-8 rounded-xl font-bold text-lg flex items-center gap-3 transition ${helpBtnStyle}`}
            >
              <LifeBuoy className="h-6 w-6" />
              {plc.PB_Toggle ? "Help Requested" : "Request Help"}
            </button>
            <button
              onClick={() => setPlc((p) => ({ ...p, PB_Enable: !p.PB_Enable }))}
              className="h-16 px-6 rounded-xl bg-surface-2 hover:bg-surface-3 font-semibold flex items-center gap-2 transition"
            >
              <Power className="h-5 w-5" />
              Toggle PB_Enable ({plc.PB_Enable ? "on" : "off"})
            </button>
          </div>
          <p className="mt-4 text-xs text-fg-muted">
            Simulated PLC · PB_Enable: {String(plc.PB_Enable)} · PB_Toggle:{" "}
            {String(plc.PB_Toggle)}
          </p>
        </section>

        <section className="rounded-2xl bg-surface-1 border border-border p-6">
          <div className="flex items-baseline justify-between mb-4">
            <h2 className="text-xl font-semibold">HelpRequestedLog</h2>
            <span className="text-xs text-fg-muted">
              getEntries · newest first
            </span>
          </div>
          {log.length === 0 ? (
            <p className="text-sm text-fg-muted py-6 text-center">
              No entries yet. Tap Request Help to open the popup.
            </p>
          ) : (
            <div className="flex flex-col gap-2">
              {log.map((e) => (
                <div
                  key={e.id}
                  className="flex flex-col gap-2 rounded-lg bg-surface-2 px-4 py-3"
                >
                  <div className="flex items-center gap-3 flex-wrap">
                    <span className="text-xs font-mono text-fg-muted w-8">
                      #{e.id}
                    </span>
                    <span className="font-semibold w-20">{e.station}</span>
                    <span
                      className={`text-xs font-bold uppercase px-2 py-1 rounded ${PRIORITY_STYLES[e.priority]}`}
                    >
                      {e.priority}
                    </span>
                    <span className="text-xs font-semibold px-2 py-1 rounded bg-surface-3 text-fg-secondary capitalize">
                      {e.category}
                    </span>
                    {e.lineStopped && (
                      <span className="text-xs font-semibold px-2 py-1 rounded bg-warning-subtle text-warning">
                        Line stopped
                      </span>
                    )}
                    {e.safetyIssue && (
                      <span className="text-xs font-semibold px-2 py-1 rounded bg-danger/25 text-danger">
                        Safety
                      </span>
                    )}
                    {e.estimatedDowntimeMin !== null && (
                      <span className="text-xs text-fg-muted">
                        ETA:{" "}
                        {e.estimatedDowntimeMin === -1
                          ? "unknown"
                          : `${e.estimatedDowntimeMin} min`}
                      </span>
                    )}
                    <span className="flex-1" />
                    <span
                      className={`text-xs font-semibold px-2 py-1 rounded ${
                        e.status === "Open"
                          ? "bg-warning-subtle text-warning"
                          : "bg-success-subtle text-success"
                      }`}
                    >
                      {e.status}
                    </span>
                    {e.status === "Open" && (
                      <button
                        onClick={() => {
                          setLog((l) =>
                            l.map((x) =>
                              x.id === e.id
                                ? { ...x, status: "Closed" as const }
                                : x,
                            ),
                          );
                          setPlc((p) => ({ ...p, PB_Toggle: false }));
                        }}
                        className="text-xs font-semibold px-3 py-1.5 rounded-md bg-surface-3 hover:bg-border transition"
                      >
                        Close
                      </button>
                    )}
                  </div>
                  <div className="text-sm text-fg-secondary flex flex-wrap gap-x-4 gap-y-1 pl-11">
                    <span>
                      <span className="text-fg-muted">Contacts:</span>{" "}
                      {e.contacts}
                    </span>
                    {e.partNumber && (
                      <span>
                        <span className="text-fg-muted">Part:</span>{" "}
                        {e.partNumber}
                      </span>
                    )}
                    {e.message && (
                      <span className="text-fg-muted italic">
                        &ldquo;{e.message}&rdquo;
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>

      {open && (
        <HelpRequestPopup
          stationName={station}
          location={location}
          plc={plc}
          onSubmit={handleSubmit}
          onCancelRequest={handleCancelRequest}
          onClose={() => setOpen(false)}
        />
      )}
    </main>
  );
}

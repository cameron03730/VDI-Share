-- Help Request Shift Report / getShiftSummary
-- One row: the four shift numbers, plus CalledSummary ('Supervisors 3  ·  AMR 2') for the "Called" line.
-- A request counts as closed only if it was closed before the shift ended
WITH shiftRequests AS (
    SELECT
        h.Contacts,
        CASE WHEN h.CompletedTimestamp <= :endDate THEN 1 ELSE 0 END      AS ClosedInShift,
        CASE WHEN h.LineStopped = 1 THEN 1 ELSE 0 END                     AS LineStopped,
        DATEDIFF(MINUTE, h.[Timestamp],
            CASE WHEN h.CompletedTimestamp <= :endDate THEN h.CompletedTimestamp ELSE :endDate END) AS MinutesOpen
    FROM HelpRequestedLog h
    WHERE h.Station IN (SELECT StationName FROM WorkStationAssignment WHERE Area IN {areas})
      AND h.[Timestamp] >= :startDate
      AND h.[Timestamp] <  :endDate
),
-- Contacts is the roster list the popup saved, e.g. 'Supervisors,Maintenance,'
called AS (
    SELECT LTRIM(RTRIM(c.value)) AS ResponderGroup, COUNT(*) AS Calls
    FROM shiftRequests r
    CROSS APPLY STRING_SPLIT(r.Contacts, ',') c
    WHERE LTRIM(RTRIM(c.value)) <> ''
    GROUP BY LTRIM(RTRIM(c.value))
)
SELECT
    totals.TotalRequests,
    totals.ClosedRequests,
    totals.TotalRequests - totals.ClosedRequests                          AS OpenRequests,
    totals.LineStoppedRequests,
    totals.LineStoppedMinutes,
    totals.AvgMinutesToClose,
    totals.LongestMinutes,
    ISNULL(calledList.CalledSummary, 'Nobody')                            AS CalledSummary
FROM (
    SELECT
        COUNT(*)                                                              AS TotalRequests,
        ISNULL(SUM(ClosedInShift), 0)                                         AS ClosedRequests,
        ISNULL(SUM(LineStopped), 0)                                           AS LineStoppedRequests,
        ISNULL(SUM(LineStopped * MinutesOpen), 0)                             AS LineStoppedMinutes,
        ISNULL(AVG(CASE WHEN ClosedInShift = 1 THEN MinutesOpen END), 0)      AS AvgMinutesToClose,
        ISNULL(MAX(MinutesOpen), 0)                                           AS LongestMinutes
    FROM shiftRequests
) totals
CROSS JOIN (
    SELECT STRING_AGG(ResponderGroup + ' ' + CAST(Calls AS varchar(10)), N'  ·  ')
               WITHIN GROUP (ORDER BY Calls DESC, ResponderGroup)         AS CalledSummary
    FROM called
) calledList;

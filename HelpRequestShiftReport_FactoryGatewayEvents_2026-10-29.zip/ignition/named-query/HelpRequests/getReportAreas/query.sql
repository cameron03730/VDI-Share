-- HelpRequests / getReportAreas
-- Every area in the station roster; HelpRequests.ShiftReport reads each one's week schedule
SELECT DISTINCT Area
FROM WorkStationAssignment
WHERE Area IS NOT NULL
  AND Area <> ''
ORDER BY Area;

"""
Purpose: Emails the Help Request Shift Reports when shifts end: one report per area to the area's
	roster, and one master report per shift to the PlantManager roster
Author: Cameron Metzgar
Company: MDI
Initial Date: 10/28/2026
Update Date: 10/29/2026
Comment: Runs from the HelpRequestShiftReport gateway timer, which only acts on Back-End-1; the module is
	imported on BE1 and BE2 so both FactoryGatewayEvents copies match. The reports run on Front-End-1
	(FactoryControl, Help Requests/...) through HelpRequests.ReportGeneration.executeReport. This library
	doesn't call SOSChecklist: it copies how the SOS reports find rosters and pick the master report's
	areas and shift, but keeps its own copy (getRosterForArea, HelpRequests/getReportAreas).
Update Notes:
	10/29/2026: moved out of StationControl into its own HelpRequests library; own roster lookup, area query
		and front-end report call instead of the SOSChecklist ones.
"""
import traceback
from java.lang import Exception as JavaError

logger = system.util.getLogger('Help Request Shift Report')

REPORT_PATH = 'Help Requests/Help Request Shift Report'
MASTER_REPORT_PATH = 'Help Requests/Help Request Shift Master Report'
MASTER_ROSTER = 'PlantManager'
# Document tags holding the end time of the last shift reported, per area and per shift name
REPORT_SENT_TAG_PATH = '[TAGIO1]JLG/Jefferson City/Admin/Help Requests/shiftReportSentByArea'
MASTER_SENT_TAG_PATH = '[TAGIO1]JLG/Jefferson City/Admin/Help Requests/masterReportSentByShift'
SHIFT_NAMES = ('Shift 1', 'Shift 2', 'Shift 3')
# Wait this long after a shift ends so the last requests get closed out
MINUTES_AFTER_SHIFT_END = 15
# Skip shifts that ended longer ago than this, so a restart or a new install doesn't send old reports
MAX_HOURS_LATE = 4


def sendEndOfShiftReports():
	'''
	Emails the area reports and the master report for every shift that has just ended.

	Called every 5 minutes by the HelpRequestShiftReport gateway timer on Back-End-1.
	Area reports: each area gets its latest ended shift once, to its own roster.
	Master report: every area that had a shift with the same name that day goes into one report,
	sent once the last of those areas finishes the shift. Each report is recorded as sent in its
	document tag right after the email goes out, so a failure part way only resends what never went.

	Args:
		None

	Returns:
		None
	'''
	now = system.date.now()

	# Every area in the station roster that has a shift folder, with its week schedule
	areaRows = system.db.runNamedQuery(project = 'FactoryGatewayEvents', path = 'HelpRequests/getReportAreas', parameters = {})
	areas = []
	schedulePaths = []
	for rowIndex in range(areaRows.getRowCount()):
		area = areaRows.getValueAt(rowIndex, 'Area')
		if not area:
			continue
		areaFolder = StationControl.DynamicView.getAreaFolder(area)
		if areaFolder is None:
			continue
		areas.append(str(area))
		schedulePaths.append(areaFolder + '/Shift/currentWeekSchedule')
	scheduleReads = system.tag.readBlocking(schedulePaths)

	# Area reports
	sentByArea = dict(system.tag.readBlocking([REPORT_SENT_TAG_PATH])[0].value)
	for areaIndex in range(len(areas)):
		area = areas[areaIndex]
		weekSchedule = scheduleReads[areaIndex].value
		if weekSchedule is None:
			continue

		# Latest shift of this area that is ready to report
		lastShift = None
		for shiftWindow in getShiftWindows(weekSchedule, now):
			if not isReadyToReport(shiftWindow['shiftEnd'], now):
				continue
			if lastShift is None or system.date.isAfter(shiftWindow['shiftEnd'], lastShift['shiftEnd']):
				lastShift = shiftWindow
		if lastShift is None:
			continue

		# Skip it if this shift was already reported
		shiftEndText = system.date.format(lastShift['shiftEnd'], 'yyyy-MM-dd HH:mm')
		if sentByArea.get(area, '') >= shiftEndText:
			continue

		sendAreaReport(area, lastShift['shiftName'], lastShift['shiftStart'], lastShift['shiftEnd'])
		sentByArea[area] = shiftEndText
		writeResult = system.tag.writeBlocking([REPORT_SENT_TAG_PATH], [sentByArea])[0]
		if not writeResult.isGood():
			logger.error('Could not record the {} shift report as sent at {}: {}'.format(area, REPORT_SENT_TAG_PATH, writeResult))

	# Master report: group every area's shifts by shift name and the day they started
	shiftGroups = {}
	for areaIndex in range(len(areas)):
		weekSchedule = scheduleReads[areaIndex].value
		if weekSchedule is None:
			continue
		for shiftWindow in getShiftWindows(weekSchedule, now):
			groupKey = shiftWindow['shiftName'] + ' ' + shiftWindow['dayText']
			if groupKey not in shiftGroups:
				shiftGroups[groupKey] = {'shiftName': shiftWindow['shiftName'], 'shiftStart': shiftWindow['shiftStart'],
					'shiftEnd': shiftWindow['shiftEnd'], 'areas': []}
			shiftGroup = shiftGroups[groupKey]
			shiftGroup['areas'].append(areas[areaIndex])
			# The report covers the earliest start to the latest end across the areas
			if system.date.isBefore(shiftWindow['shiftStart'], shiftGroup['shiftStart']):
				shiftGroup['shiftStart'] = shiftWindow['shiftStart']
			if system.date.isAfter(shiftWindow['shiftEnd'], shiftGroup['shiftEnd']):
				shiftGroup['shiftEnd'] = shiftWindow['shiftEnd']

	sentByShift = dict(system.tag.readBlocking([MASTER_SENT_TAG_PATH])[0].value)
	for groupKey in sorted(shiftGroups):
		shiftGroup = shiftGroups[groupKey]
		# Waits for the last area on this shift to finish
		if not isReadyToReport(shiftGroup['shiftEnd'], now):
			continue
		shiftEndText = system.date.format(shiftGroup['shiftEnd'], 'yyyy-MM-dd HH:mm')
		if sentByShift.get(shiftGroup['shiftName'], '') >= shiftEndText:
			continue

		sendMasterReport(shiftGroup['shiftName'], shiftGroup['shiftStart'], shiftGroup['shiftEnd'], sorted(shiftGroup['areas']))
		sentByShift[shiftGroup['shiftName']] = shiftEndText
		writeResult = system.tag.writeBlocking([MASTER_SENT_TAG_PATH], [sentByShift])[0]
		if not writeResult.isGood():
			logger.error('Could not record the {} master report as sent at {}: {}'.format(shiftGroup['shiftName'], MASTER_SENT_TAG_PATH, writeResult))


def getShiftWindows(weekSchedule, now):
	'''
	Lists every shift an area has scheduled yesterday and today, with its start and end time.

	Yesterday is included so a shift that runs past midnight is found the morning it ends.
	Breaks don't matter: a shift runs from its first range's start to its last range's end.

	Args:
		weekSchedule (dict): The area's Shift/currentWeekSchedule value, {shiftName: {dayName: {'enabled': bool, 'time_string': '5:00-8:00, 8:15-12:00,12:30-15:00'}}}.
		now (Date): The current time.

	Returns:
		list: One dict per enabled shift, {'shiftName': str, 'dayText': 'yyyy-MM-dd' it started, 'shiftStart': Date, 'shiftEnd': Date}.
	'''
	shiftWindows = []
	for daysBack in [1, 0]:
		day = system.date.addDays(system.date.midnight(now), -daysBack)
		dayText = system.date.format(day, 'yyyy-MM-dd')
		dayName = system.date.format(day, 'EEEE')
		for shiftName in SHIFT_NAMES:
			daySchedule = (weekSchedule.get(shiftName) or {}).get(dayName) or {}
			if not daySchedule.get('enabled', False):
				continue

			# First range's start to last range's end
			timeRanges = daySchedule.get('time_string').split(',')
			startTime = timeRanges[0].strip().split('-')[0]
			endTime = timeRanges[-1].strip().split('-')[1]
			shiftStart = system.date.parse(dayText + ' ' + startTime, 'yyyy-MM-dd H:mm')
			shiftEnd = system.date.parse(dayText + ' ' + endTime, 'yyyy-MM-dd H:mm')
			# Shift runs past midnight
			if not system.date.isAfter(shiftEnd, shiftStart):
				shiftEnd = system.date.addDays(shiftEnd, 1)
			shiftWindows.append({'shiftName': shiftName, 'dayText': dayText, 'shiftStart': shiftStart, 'shiftEnd': shiftEnd})
	return shiftWindows


def isReadyToReport(shiftEnd, now):
	'''
	Tells whether a shift that ends at shiftEnd should be reported now.

	Ready from MINUTES_AFTER_SHIFT_END after the end, until MAX_HOURS_LATE after it.

	Args:
		shiftEnd (Date): End of the shift.
		now (Date): The current time.

	Returns:
		bool: True when the report should go out now.
	'''
	readyTime = system.date.addMinutes(shiftEnd, MINUTES_AFTER_SHIFT_END)
	lateTime = system.date.addHours(shiftEnd, MAX_HOURS_LATE)
	return not system.date.isBefore(now, readyTime) and not system.date.isAfter(now, lateTime)


def getRosterForArea(area):
	'''
	Finds the alarm roster that gets an area's shift report.

	Matches the same rosters the SOS checklist area report uses: the roster whose name contains the
	area's folder name. Assembly areas (Main Line, Cab Sub, Boom Sub, ...) all match the roster with
	"Assembly" in its name, because for an Assembly folder the name one level up is used.

	Args:
		area (str): Area name as WorkStationAssignment.Area holds it, e.g. 'Main Line'.

	Returns:
		str: The roster name, or None when no roster matches.
	'''
	# '[TAGIO2]JLG/Jefferson City/Assembly/Main Line' matches on 'Assembly', '[TAGIO1]JLG/Jefferson City/Paint' on 'Paint'
	folderNames = StationControl.DynamicView.getAreaFolder(area).split('/')
	rosterKey = folderNames[-2] if 'Assembly' in folderNames else folderNames[-1]
	for rosterName in system.alarm.getRosters():
		if rosterKey.lower() in rosterName.lower():
			return str(rosterName)
	return None


def runReport(reportPath, reportParams):
	'''
	Runs a FactoryControl report on Front-End-1 and returns the PDF bytes.

	Report resources live in the front-end project, so the back end asks Front-End-1 to run it
	through its executeFunction handler, which calls HelpRequests.ReportGeneration.executeReport.

	Args:
		reportPath (str): Report path in FactoryControl, e.g. 'Help Requests/Help Request Shift Report'.
		reportParams (dict): Report parameters: startDate, endDate, shiftName, areaName, areas.

	Returns:
		bytes: The report as a PDF.
	'''
	payload = {
		'function': 'HelpRequests.ReportGeneration.executeReport',
		'params': {'reportPath': reportPath, 'params': reportParams}
	}
	# Front-End-1 runs the report and sends back the PDF bytes
	try:
		return system.util.sendRequest(
			project = 'FactoryControl',
			messageHandler = 'executeFunction',
			payload = payload,
			remoteServer = GatewayConfig.getFrontEnd_1(),
			timeoutSec = 30
		)
	except (JavaError, Exception):
		logger.error('Front-End-1 could not run {} for {}:\n{}'.format(reportPath, reportParams, traceback.format_exc()))
		raise


def sendAreaReport(area, shiftName, shiftStart, shiftEnd):
	'''
	Runs the Help Request Shift Report for one area and shift and emails the PDF to the area's roster.

	The timer calls this through sendEndOfShiftReports. It can also be run by hand from the
	Back-End-1 script console to resend a shift, e.g.
	sendAreaReport('Main Line', 'Shift 1', system.date.parse('2026-10-27 05:00', 'yyyy-MM-dd HH:mm'), system.date.parse('2026-10-27 15:00', 'yyyy-MM-dd HH:mm')).

	Args:
		area (str): Area name as WorkStationAssignment.Area holds it, e.g. 'Main Line'.
		shiftName (str): Shift name from the week schedule, e.g. 'Shift 1'.
		shiftStart (Date): Start of the shift.
		shiftEnd (Date): End of the shift.

	Returns:
		bool: True when the email was sent, False when the area has no roster or the roster has no emails.
	'''
	reportBytes = runReport(REPORT_PATH, {
		'startDate': shiftStart,
		'endDate': shiftEnd,
		'shiftName': shiftName,
		'areaName': area,
		'areas': General.createQueryString([area])
	})

	rosterName = getRosterForArea(area)
	if rosterName is None:
		logger.warn('No roster for {}, the {} shift report was not emailed'.format(area, shiftName))
		return False
	emailList = Admin.EmailRoster.getEmailsFromRoster(rosterName)
	if not emailList:
		logger.warn('Roster {} has no emails, the {} {} shift report was not emailed'.format(rosterName, area, shiftName))
		return False

	dateText = system.date.format(shiftStart, 'MMMM dd, yyyy')
	timeText = system.date.format(shiftStart, 'h:mm a') + ' - ' + system.date.format(shiftEnd, 'h:mm a')
	emailSubject = 'Help Request Shift Report - {} - {}'.format(area, shiftName)
	emailBody = """
<html>
<body style="font-family: Arial, sans-serif; font-size: 14px; color: #333;">

    <p>Hello,</p>

    <p>The <strong>Help Request Shift Report</strong> for <strong>{area}</strong> &mdash;
    <strong>{shiftName}</strong> is attached.</p>

    <table style="border-collapse: collapse; margin: 10px 0;">
        <tr>
            <td style="padding: 4px 12px 4px 0; color: #555;">Report Date:</td>
            <td><strong>{date}</strong></td>
        </tr>
        <tr>
            <td style="padding: 4px 12px 4px 0; color: #555;">Shift:</td>
            <td><strong>{shiftName} ({time})</strong></td>
        </tr>
    </table>

    <p style="color: #555; font-size: 13px;">This report includes:</p>
    <ul style="line-height: 1.8;">
        <li>Shift totals, a chart of requests by category, and who was called</li>
        <li>Every help request raised this shift, grouped by category; <strong>&#9733;</strong> marks requests that stopped the line</li>
        <li>Tinted rows were still open when the shift ended</li>
    </ul>

    <p style="color: #888; font-size: 12px;">This is an automated message &mdash; please do not reply directly to this email.</p>

</body>
</html>
""".format(area=area, shiftName=shiftName, date=dateText, time=timeText)

	Admin.EmailRoster.sendEmailToRosterWithAttachment(
		rosterName = rosterName,
		emailSubject = emailSubject,
		emailBody = emailBody,
		attachmentNames = ['HelpRequest_Shift_Report.pdf'],
		attachmentData = [reportBytes],
		emailList = emailList
	)
	logger.info('Sent the {} {} help request shift report to {}'.format(area, shiftName, rosterName))
	return True


def sendMasterReport(shiftName, shiftStart, shiftEnd, areas):
	'''
	Runs the Help Request Shift Master Report for every area on a shift and emails it to the PlantManager roster.

	The timer calls this through sendEndOfShiftReports. It can also be run by hand from the
	Back-End-1 script console, e.g.
	sendMasterReport('Shift 1', system.date.parse('2026-10-27 05:00', 'yyyy-MM-dd HH:mm'), system.date.parse('2026-10-27 15:30', 'yyyy-MM-dd HH:mm'), ['Cab Sub', 'Main Line']).

	Args:
		shiftName (str): Shift name from the week schedules, e.g. 'Shift 1'.
		shiftStart (Date): Earliest start of this shift across the areas.
		shiftEnd (Date): Latest end of this shift across the areas.
		areas (list): Areas that had this shift scheduled, as WorkStationAssignment.Area holds them.

	Returns:
		bool: True when the email was sent, False when the PlantManager roster has no emails.
	'''
	reportBytes = runReport(MASTER_REPORT_PATH, {
		'startDate': shiftStart,
		'endDate': shiftEnd,
		'shiftName': shiftName,
		'areaName': 'All areas',
		'areas': General.createQueryString(areas)
	})

	emailList = Admin.EmailRoster.getEmailsFromRoster(MASTER_ROSTER)
	if not emailList:
		logger.warn('Roster {} has no emails, the {} master report was not emailed'.format(MASTER_ROSTER, shiftName))
		return False

	dateText = system.date.format(shiftStart, 'MMMM dd, yyyy')
	timeText = system.date.format(shiftStart, 'h:mm a') + ' - ' + system.date.format(shiftEnd, 'h:mm a')
	areaListItems = ''.join(['<li>{}</li>'.format(area) for area in areas])
	emailSubject = 'Help Request Shift Master Report - {}'.format(shiftName)
	emailBody = """
<html>
<body style="font-family: Arial, sans-serif; font-size: 14px; color: #333;">

    <p>Hello,</p>

    <p>The <strong>Help Request Shift Master Report</strong> for <strong>{date}</strong> &mdash;
    <strong>{shiftName}</strong> is attached.</p>

    <table style="border-collapse: collapse; margin: 10px 0;">
        <tr>
            <td style="padding: 4px 12px 4px 0; color: #555;">Report Date:</td>
            <td><strong>{date}</strong></td>
        </tr>
        <tr>
            <td style="padding: 4px 12px 4px 0; color: #555;">Shift:</td>
            <td><strong>{shiftName} ({time})</strong></td>
        </tr>
    </table>

    <p style="color: #555; font-size: 13px;">Areas on this shift included in this report:</p>
    <ul style="line-height: 1.8;">
        {areaListItems}
    </ul>

    <p style="color: #555; font-size: 13px;">This report includes:</p>
    <ul style="line-height: 1.8;">
        <li>Plant totals, a chart of requests by category, who was called, and each area's totals</li>
        <li>Every help request raised this shift, grouped by category; <strong>&#9733;</strong> marks requests that stopped the line</li>
        <li>Tinted rows were still open when the shift ended</li>
    </ul>

    <p style="color: #888; font-size: 12px;">This is an automated message &mdash; please do not reply directly to this email.</p>

</body>
</html>
""".format(shiftName=shiftName, date=dateText, time=timeText, areaListItems=areaListItems)

	Admin.EmailRoster.sendEmailToRosterWithAttachment(
		rosterName = MASTER_ROSTER,
		emailSubject = emailSubject,
		emailBody = emailBody,
		attachmentNames = ['HelpRequest_Shift_Master_Report.pdf'],
		attachmentData = [reportBytes],
		emailList = emailList
	)
	logger.info('Sent the {} help request master report for {}'.format(shiftName, ', '.join(areas)))
	return True
